import { useState } from 'react';

export default function Pricing() {
  const [isAnnual, setIsAnnual] = useState(true);

  const plans = [
    {
      symbol: '🥇',
      name: 'XAUUSD Gold Bot',
      description: 'Master the gold market with our specialized AI bot',
      monthlyPrice: 99,
      annualPrice: 79,
      color: 'gold',
      borderColor: 'border-gold/30',
      bgColor: 'bg-gold/10',
      textColor: 'text-gold',
      popular: false,
      features: [
        'XAUUSD AI Trading Bot',
        'Gold-specific AI models',
        'Macro event detection',
        'London & NY session optimization',
        'Central bank flow analysis',
        'DXY correlation engine',
        'Up to 50 trades/day',
        'Risk management tools',
        'Performance analytics',
        'Email support',
        'Paper trading mode',
      ],
      cta: 'Start Gold Bot Trial',
    },
    {
      symbol: '₿',
      name: 'BTC Bitcoin Bot',
      description: 'Dominate crypto with 24/7 automated Bitcoin trading',
      monthlyPrice: 149,
      annualPrice: 119,
      color: 'orange',
      borderColor: 'border-orange-500/30',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-orange-400',
      popular: false,
      features: [
        'BTC AI Trading Bot',
        'On-chain whale tracking',
        'Sentiment analysis (500+ sources)',
        'Funding rate arbitrage',
        'Liquidation cascade detection',
        'Multi-exchange support (10+)',
        'Unlimited trades/day',
        'Advanced risk management',
        'Real-time alerts',
        'API access',
        'Backtesting engine',
        'Priority 24/7 support',
        'Portfolio analytics',
      ],
      cta: 'Start BTC Bot Trial',
    },
    {
      symbol: '💶',
      name: 'EURUSD Forex Bot',
      description: 'Precision forex trading on the world\'s top currency pair',
      monthlyPrice: 89,
      annualPrice: 69,
      color: 'blue',
      borderColor: 'border-blue-500/30',
      bgColor: 'bg-blue-500/10',
      textColor: 'text-blue-400',
      popular: false,
      features: [
        'EURUSD AI Trading Bot',
        'ECB & Fed policy tracker',
        'Session-based strategies',
        'Order flow & liquidity analysis',
        'Technical pattern recognition',
        'Low-spread optimization',
        'Up to 100 trades/day',
        'Tight stop-loss system',
        'Performance analytics',
        'Strategy backtesting',
        'Email + chat support',
        'Paper trading mode',
      ],
      cta: 'Start EURUSD Bot Trial',
    },
    {
      symbol: '🚀',
      name: 'SuperBot',
      description: 'NS100 + US Oil — Multi-asset powerhouse',
      monthlyPrice: 179,
      annualPrice: 139,
      color: 'purple',
      borderColor: 'border-purple-500/30',
      bgColor: 'bg-purple-500/10',
      textColor: 'text-purple-400',
      popular: true,
      features: [
        'NS100 (Nasdaq 100) Bot',
        'USOIL (Crude Oil) Bot',
        'Cross-asset correlation AI',
        'Earnings season optimization',
        'Oil inventory data analysis',
        'Fed rate decision engine',
        'Unlimited trades/day',
        'Multi-broker support',
        'Advanced risk management',
        'Real-time alerts',
        'API access',
        'Backtesting engine',
        'Priority 24/7 support',
        'Dedicated account manager',
      ],
      cta: 'Start SuperBot Trial',
    },
  ];

  return (
    <section id="pricing" className="py-20 relative">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Choose Your <span className="gradient-text">Trading Bot</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg mb-8">
            Pick the bot that matches your market. Each plan includes a 1-week free trial with full access.
          </p>

          {/* Toggle */}
          <div className="inline-flex items-center gap-3 bg-dark-light rounded-full p-1">
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                !isAnnual ? 'bg-primary text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                isAnnual ? 'bg-primary text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Annual <span className="text-accent text-xs ml-1">Save 20%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`relative rounded-2xl p-6 transition-all duration-300 hover:-translate-y-2 glass-card border ${plan.borderColor} ${
                plan.popular ? 'ring-2 ring-primary' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1 bg-gradient-to-r from-primary to-accent rounded-full text-xs font-bold uppercase tracking-wider whitespace-nowrap">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <div className={`w-14 h-14 rounded-xl ${plan.bgColor} flex items-center justify-center text-3xl mb-4`}>
                  {plan.symbol}
                </div>
                <h3 className="text-lg font-bold mb-1">{plan.name}</h3>
                <p className="text-sm text-gray-400">{plan.description}</p>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold">
                    ${isAnnual ? plan.annualPrice : plan.monthlyPrice}
                  </span>
                  <span className="text-gray-400 text-sm">/month</span>
                </div>
                {isAnnual && (
                  <p className="text-xs text-accent mt-1">
                    Billed annually (${(isAnnual ? plan.annualPrice : plan.monthlyPrice) * 12}/year)
                  </p>
                )}
              </div>

              <button
                className={`w-full py-3 rounded-xl font-semibold text-sm transition-all mb-6 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-primary to-primary-dark hover:shadow-lg hover:shadow-primary/30'
                    : 'bg-white/5 hover:bg-white/10 border border-white/10'
                }`}
              >
                {plan.cta}
              </button>

              <ul className="space-y-2">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm">
                    <svg className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-300 text-xs">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 1-week trial notice */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-2 text-sm text-gray-400">
            <svg className="w-5 h-5 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>1-week free trial • No credit card required • Cancel anytime</span>
          </div>
        </div>
      </div>
    </section>
  );
}
