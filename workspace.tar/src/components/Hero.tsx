export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center hero-gradient pt-16">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
            <span className="text-sm text-primary-light font-medium">4 Specialized AI Trading Bots</span>
          </div>

          {/* Main heading */}
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold leading-tight mb-6">
            Trade Smarter with
            <br />
            <span className="gradient-text">AI Trading Bots</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-6">
            Four specialized AI-powered bots for the world's most traded markets — Gold, Bitcoin, Forex, Indices & Oil. 
            Execute trades 24/7 with precision, speed, and zero emotions.
          </p>

          {/* 4 Bot Badges */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
            <span className="px-4 py-2 rounded-full bg-gold/10 border border-gold/30 text-gold font-semibold text-sm">
              🥇 XAUUSD — Gold
            </span>
            <span className="px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 font-semibold text-sm">
              ₿ BTC — Bitcoin
            </span>
            <span className="px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 font-semibold text-sm">
              💶 EURUSD — Forex
            </span>
            <span className="px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 font-semibold text-sm">
              🚀 NS100 + US Oil — SuperBot
            </span>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <a
              href="#pricing"
              className="px-8 py-4 bg-gradient-to-r from-primary to-primary-dark rounded-xl font-semibold text-lg transition-all hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5"
            >
              View Premium Packages
            </a>
            <a
              href="#bots"
              className="px-8 py-4 border border-white/10 rounded-xl font-semibold text-lg text-gray-300 hover:text-white hover:border-white/20 transition-all"
            >
              Explore Bots →
            </a>
          </div>

          {/* Trading dashboard preview */}
          <div className="relative max-w-4xl mx-auto">
            <div className="glass-card rounded-2xl p-6 animate-float">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="ml-2 text-xs text-gray-400">TradeBot Pro — Live Dashboard</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {/* XAUUSD */}
                <div className="bg-dark/50 rounded-xl p-4 border border-gold/20">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">🥇</span>
                    <span className="text-xs font-bold text-gold">XAUUSD</span>
                  </div>
                  <div className="text-xl font-bold text-accent">+$4,280</div>
                  <div className="text-xs text-accent mt-1">↑ 18.2%</div>
                  <div className="text-xs text-gray-400 mt-1">Win: 89%</div>
                </div>
                {/* BTC */}
                <div className="bg-dark/50 rounded-xl p-4 border border-orange-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">₿</span>
                    <span className="text-xs font-bold text-orange-400">BTC/USD</span>
                  </div>
                  <div className="text-xl font-bold text-accent">+$5,120</div>
                  <div className="text-xs text-accent mt-1">↑ 22.7%</div>
                  <div className="text-xs text-gray-400 mt-1">Win: 85%</div>
                </div>
                {/* EURUSD */}
                <div className="bg-dark/50 rounded-xl p-4 border border-blue-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">💶</span>
                    <span className="text-xs font-bold text-blue-400">EURUSD</span>
                  </div>
                  <div className="text-xl font-bold text-accent">+$3,447</div>
                  <div className="text-xs text-accent mt-1">↑ 12.5%</div>
                  <div className="text-xs text-gray-400 mt-1">Win: 91%</div>
                </div>
                {/* NS100 + USOIL */}
                <div className="bg-dark/50 rounded-xl p-4 border border-purple-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">🚀</span>
                    <span className="text-xs font-bold text-purple-400">SuperBot</span>
                  </div>
                  <div className="text-xl font-bold text-accent">+$6,890</div>
                  <div className="text-xs text-accent mt-1">↑ 26.4%</div>
                  <div className="text-xs text-gray-400 mt-1">Win: 88%</div>
                </div>
              </div>
              {/* Chart visualization */}
              <div className="mt-4 bg-dark/50 rounded-xl p-4">
                <div className="flex items-end gap-1 h-20">
                  {[40, 55, 35, 65, 45, 70, 50, 80, 60, 75, 85, 70, 90, 75, 95, 80, 88, 92, 85, 98].map((h, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-t bg-gradient-to-t from-primary/50 to-accent/50"
                      style={{ height: `${h}%` }}
                    ></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
