export default function Features() {
  const bots = [
    {
      symbol: '🥇',
      name: 'XAUUSD Bot',
      subtitle: 'Gold Trading Bot',
      color: 'gold',
      borderColor: 'border-gold/30',
      bgColor: 'bg-gold/10',
      textColor: 'text-gold',
      description: 'Specialized AI bot trained on decades of gold market data. Exploits gold\'s unique volatility patterns, safe-haven flows, and correlation with macro events for consistent profits.',
      features: [
        'Trained on 20+ years of gold price data',
        'News-driven macro event detection',
        'London/NY session optimization',
        'Central bank flow analysis',
        'DXY correlation engine',
        'Average 89% win rate',
      ],
      stats: { winRate: '89%', avgTrade: '$142', monthly: '+18.2%' },
      bestFor: 'Safe-haven traders, macro investors, hedging strategies',
    },
    {
      symbol: '₿',
      name: 'BTC Bot',
      subtitle: 'Bitcoin Trading Bot',
      color: 'orange',
      borderColor: 'border-orange-500/30',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-orange-400',
      description: '24/7 crypto-native bot leveraging blockchain data, on-chain metrics, and sentiment analysis. Captures Bitcoin\'s high volatility with precision entries and smart risk management.',
      features: [
        'On-chain metrics & whale tracking',
        'Sentiment analysis from 500+ sources',
        'Funding rate arbitrage',
        'Liquidation cascade detection',
        'Multi-exchange execution',
        'Average 85% win rate',
      ],
      stats: { winRate: '85%', avgTrade: '$380', monthly: '+22.7%' },
      bestFor: 'Crypto traders, volatility seekers, 24/7 market participants',
    },
    {
      symbol: '💶',
      name: 'EURUSD Bot',
      subtitle: 'Forex Trading Bot',
      color: 'blue',
      borderColor: 'border-blue-500/30',
      bgColor: 'bg-blue-500/10',
      textColor: 'text-blue-400',
      description: 'The world\'s most traded currency pair, optimized by AI. Our bot exploits micro-inefficiencies in EUR/USD with tight spreads, high liquidity, and ECB/Fed policy analysis.',
      features: [
        'ECB & Fed policy tracker',
        'Session-based strategy (Asia/London/NY)',
        'Order flow & liquidity analysis',
        'Technical pattern recognition',
        'Low-spread optimization',
        'Average 91% win rate',
      ],
      stats: { winRate: '91%', avgTrade: '$95', monthly: '+12.5%' },
      bestFor: 'Forex traders, scalpers, low-risk consistent returns',
    },
    {
      symbol: '🚀',
      name: 'SuperBot',
      subtitle: 'NS100 + US Oil Trading Bot',
      color: 'purple',
      borderColor: 'border-purple-500/30',
      bgColor: 'bg-purple-500/10',
      textColor: 'text-purple-400',
      description: 'SuperBot is the ultimate multi-asset bot combining Nasdaq 100 (NS100) and US Crude Oil (USOIL). Exploits the high volatility of tech indices and energy markets with AI-driven correlation analysis and momentum strategies.',
      features: [
        'NS100 (Nasdaq 100) momentum engine',
        'USOIL (Crude Oil) supply/demand AI',
        'Cross-asset correlation analysis',
        'Earnings season & inventory data',
        'Fed rate decision optimization',
        'Average 88% win rate',
      ],
      stats: { winRate: '88%', avgTrade: '$265', monthly: '+26.4%' },
      bestFor: 'Index traders, energy market traders, multi-asset diversification',
    },
  ];

  return (
    <section id="bots" className="py-20 relative">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Our <span className="gradient-text">4 Specialized Bots</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Each bot is purpose-built and AI-trained for specific markets. 
            Focused expertise beats generic solutions every time.
          </p>
        </div>

        <div className="space-y-8">
          {bots.map((bot, i) => (
            <div
              key={i}
              className={`glass-card rounded-2xl p-6 lg:p-8 border ${bot.borderColor} hover:-translate-y-1 transition-all duration-300`}
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left: Info */}
                <div className="lg:col-span-2">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-14 h-14 rounded-xl ${bot.bgColor} flex items-center justify-center text-3xl`}>
                      {bot.symbol}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{bot.name}</h3>
                      <p className={`text-sm ${bot.textColor}`}>{bot.subtitle}</p>
                    </div>
                  </div>
                  <p className="text-gray-300 leading-relaxed mb-6">{bot.description}</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                    {bot.features.map((feature, j) => (
                      <div key={j} className="flex items-start gap-2">
                        <svg className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-sm text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <span className="font-semibold text-gray-300">Best for:</span>
                    <span>{bot.bestFor}</span>
                  </div>
                </div>

                {/* Right: Stats */}
                <div className="space-y-4">
                  <div className={`${bot.bgColor} rounded-xl p-5 border ${bot.borderColor}`}>
                    <div className="text-xs text-gray-400 mb-1">Win Rate</div>
                    <div className={`text-3xl font-bold ${bot.textColor}`}>{bot.stats.winRate}</div>
                  </div>
                  <div className={`${bot.bgColor} rounded-xl p-5 border ${bot.borderColor}`}>
                    <div className="text-xs text-gray-400 mb-1">Avg. Profit / Trade</div>
                    <div className={`text-3xl font-bold ${bot.textColor}`}>{bot.stats.avgTrade}</div>
                  </div>
                  <div className={`${bot.bgColor} rounded-xl p-5 border ${bot.borderColor}`}>
                    <div className="text-xs text-gray-400 mb-1">Monthly Return</div>
                    <div className={`text-3xl font-bold text-accent`}>{bot.stats.monthly}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
