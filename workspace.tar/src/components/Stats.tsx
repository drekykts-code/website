export default function Stats() {
  const stats = [
    { value: '4', label: 'Specialized Bots', icon: '🤖' },
    { value: '50,000+', label: 'Active Traders', icon: '👥' },
    { value: '$2.4B+', label: 'Trading Volume', icon: '💰' },
    { value: '87%', label: 'Average Win Rate', icon: '🎯' },
  ];

  return (
    <section className="py-16 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl mb-2">{stat.icon}</div>
              <div className="text-2xl sm:text-3xl font-bold gradient-text">{stat.value}</div>
              <div className="text-sm text-gray-400 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
