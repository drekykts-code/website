export default function Testimonials() {
  const testimonials = [
    {
      name: 'Marcus Chen',
      role: 'Gold Trader',
      avatar: '👨‍💻',
      bot: 'XAUUSD Bot',
      botColor: 'text-gold bg-gold/10',
      rating: 5,
      text: "The XAUUSD bot is incredible. It detected the gold rally before most analysts and executed perfectly. My account grew 18% in the first month alone.",
      profit: '+$8,400/mo',
    },
    {
      name: 'Sarah Williams',
      role: 'Crypto Trader',
      avatar: '👩‍💼',
      bot: 'BTC Bot',
      botColor: 'text-orange-400 bg-orange-500/10',
      rating: 5,
      text: "The BTC bot trades 24/7 and catches moves I would have missed while sleeping. The whale tracking feature alone has paid for the subscription 10x over.",
      profit: '+$12,200/mo',
    },
    {
      name: 'David Park',
      role: 'Forex Trader',
      avatar: '👨‍💼',
      bot: 'EURUSD Bot',
      botColor: 'text-blue-400 bg-blue-500/10',
      rating: 5,
      text: "I've tried many forex EAs but the EURUSD bot is on another level. The session-based strategies and ECB tracking give it a real edge. 91% win rate is no joke.",
      profit: '+$5,600/mo',
    },
    {
      name: 'Emily Rodriguez',
      role: 'Bundle User',
      avatar: '👩‍🔬',
      bot: 'All 3 Bots',
      botColor: 'text-primary-light bg-primary/10',
      rating: 5,
      text: "I got the bundle deal and it's the best investment I've made. Diversified across gold, bitcoin, and forex — my portfolio is more stable and profitable than ever.",
      profit: '+$22,800/mo',
    },
    {
      name: 'James Thompson',
      role: 'BTC Scalper',
      avatar: '🧑‍💻',
      bot: 'BTC Bot',
      botColor: 'text-orange-400 bg-orange-500/10',
      rating: 5,
      text: "The funding rate arbitrage feature is genius. The BTC bot identifies opportunities across exchanges that I never knew existed. Consistent daily profits.",
      profit: '+$9,100/mo',
    },
    {
      name: 'Aisha Patel',
      role: 'Gold Investor',
      avatar: '👩‍🏫',
      bot: 'XAUUSD Bot',
      botColor: 'text-gold bg-gold/10',
      rating: 5,
      text: "As a long-term gold investor, I use the XAUUSD bot for tactical entries and exits around major events. It's like having a professional gold desk at my fingertips.",
      profit: '+$6,300/mo',
    },
    {
      name: 'Robert Kim',
      role: 'Index & Energy Trader',
      avatar: '🧑‍💼',
      bot: 'SuperBot',
      botColor: 'text-purple-400 bg-purple-500/10',
      rating: 5,
      text: "SuperBot is a beast. Trading NS100 and US Oil simultaneously with correlation analysis gives me an edge I didn't know existed. Best $179 I've ever spent.",
      profit: '+$14,500/mo',
    },
    {
      name: 'Lisa Martinez',
      role: 'Multi-Asset Trader',
      avatar: '👩‍💻',
      bot: 'SuperBot',
      botColor: 'text-purple-400 bg-purple-500/10',
      rating: 5,
      text: "I love that I can trade both Nasdaq and Oil from SuperBot. The earnings season optimization is incredible — it predicted tech moves before the big players.",
      profit: '+$11,200/mo',
    },
  ];

  return (
    <section id="testimonials" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Trusted by <span className="gradient-text">50,000+ Traders</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Real results from traders using our XAUUSD, BTC, EURUSD, and SuperBot (NS100 + US Oil) bots.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div key={i} className="glass-card rounded-2xl p-6 hover:border-primary/30 transition-all">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <svg key={j} className="w-4 h-4 text-gold" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded ${t.botColor}`}>
                  {t.bot}
                </span>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-4">"{t.text}"</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{t.avatar}</span>
                  <div>
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-gray-400">{t.role}</div>
                  </div>
                </div>
                <div className="text-xs font-bold text-accent bg-accent/10 px-2 py-1 rounded">
                  {t.profit}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
