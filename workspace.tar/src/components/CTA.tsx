export default function CTA() {
  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden">
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-dark-light to-accent/20"></div>
          
          <div className="relative px-8 py-16 sm:px-16 sm:py-20 text-center">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Ready to <span className="gradient-text">Automate Your Trading</span>?
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto mb-6">
              Choose your bot and start trading in minutes. 
              Gold, Bitcoin, Forex, or Nasdaq & Oil — we've got you covered.
            </p>

            {/* Bot icons */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center text-2xl">
                🥇
              </div>
              <div className="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-2xl">
                ₿
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-2xl">
                💶
              </div>
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-2xl">
                🚀
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="#pricing"
                className="px-8 py-4 bg-gradient-to-r from-primary to-primary-dark rounded-xl font-semibold text-lg transition-all hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 animate-pulse-glow"
              >
                Start Free Trial →
              </a>
              <a
                href="#bots"
                className="px-8 py-4 border border-white/10 rounded-xl font-semibold text-lg text-gray-300 hover:text-white hover:border-white/20 transition-all"
              >
                Compare Bots
              </a>
            </div>
            <p className="text-xs text-gray-500 mt-6">
              ✓ 1-week free trial &nbsp; ✓ No credit card required &nbsp; ✓ Cancel anytime
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
