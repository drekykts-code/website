import { useState } from 'react';

export default function FAQ() {
  const faqs = [
    {
      question: 'What markets do your bots trade?',
      answer: 'We offer 4 specialized bots: XAUUSD (Gold), BTC/USD (Bitcoin), EURUSD (Euro/US Dollar Forex), and SuperBot covering NS100 (Nasdaq 100) and US Oil (Crude Oil). Each bot is purpose-built and AI-trained specifically for its market — no generic "one-size-fits-all" approach.',
    },
    {
      question: 'How does the XAUUSD Gold Bot work?',
      answer: 'The Gold Bot is trained on 20+ years of gold price data and exploits gold\'s unique characteristics: safe-haven flows, central bank activity, DXY correlation, and macro event reactions. It optimizes for London and New York sessions where gold liquidity is highest.',
    },
    {
      question: 'How does the BTC Bot handle crypto volatility?',
      answer: 'The Bitcoin Bot runs 24/7 using on-chain metrics, whale wallet tracking, sentiment analysis from 500+ sources, and funding rate arbitrage across exchanges. It detects liquidation cascades and adjusts position sizing based on real-time volatility.',
    },
    {
      question: 'How does the EURUSD Bot achieve 91% win rate?',
      answer: 'The EURUSD Bot exploits the tight spreads and high liquidity of the world\'s most traded currency pair. It uses ECB/Fed policy tracking, session-based strategies (Asia/London/NY), order flow analysis, and advanced technical pattern recognition.',
    },
    {
      question: 'Is my money safe with these bots?',
      answer: 'Absolutely. We never hold your funds. The bots connect to your exchange/broker accounts via API keys with trade-only permissions (no withdrawal access). We use bank-grade 256-bit encryption and TLS 1.3 for all communications.',
    },
    {
      question: 'How does SuperBot (NS100 + US Oil) work?',
      answer: 'SuperBot combines two high-volatility markets: Nasdaq 100 (tech indices) and US Crude Oil (energy). It uses cross-asset correlation analysis, earnings season optimization, oil inventory data, and Fed rate decision engines to trade both markets simultaneously with intelligent position sizing.',
    },
    {
      question: 'Can I buy all 4 bots together?',
      answer: 'Yes! Our Ultimate Bundle plan gives you access to all 4 bots (XAUUSD + BTC + EURUSD + NS100/USOIL) at a 40% discount. This is ideal for traders who want maximum diversification across commodities, crypto, forex, indices, and energy markets.',
    },
    {
      question: 'What brokers/exchanges are supported?',
      answer: 'XAUUSD & EURUSD bots support MT4/MT5, cTrader, and 15+ forex brokers. The BTC bot supports Binance, Coinbase, Kraken, Bybit, OKX, KuCoin, and 10+ crypto exchanges.',
    },
    {
      question: 'Do you offer a free trial?',
      answer: 'Yes! Every bot comes with a 1-week free trial with full features. No credit card required. You can also use paper trading mode to test strategies risk-free before going live.',
    },
    {
      question: 'What is the average monthly return?',
      answer: 'Returns vary by market conditions. XAUUSD averages +18.2%/month, BTC averages +22.7%/month, and EURUSD averages +12.5%/month based on historical data. Past performance does not guarantee future results.',
    },
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Frequently Asked <span className="gradient-text">Questions</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Everything about our XAUUSD, BTC, EURUSD, and SuperBot (NS100 + US Oil) trading bots.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="glass-card rounded-xl overflow-hidden transition-all"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left"
              >
                <span className="font-semibold text-sm sm:text-base pr-4">{faq.question}</span>
                <svg
                  className={`w-5 h-5 text-primary flex-shrink-0 transition-transform ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {openIndex === i && (
                <div className="px-5 pb-5">
                  <p className="text-gray-400 text-sm leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
