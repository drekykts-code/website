export default function GitHubIntegration() {
  const features = [
    {
      icon: '🔗',
      title: 'One-Click Connect',
      description: 'Link your GitHub account in seconds with OAuth 2.0 secure authentication.',
    },
    {
      icon: '📦',
      title: 'Strategy Repository',
      description: 'Access 200+ open-source trading strategies from our community GitHub repos.',
    },
    {
      icon: '🔄',
      title: 'Auto-Deploy',
      description: 'Push strategy code to GitHub and auto-deploy to your bot with CI/CD pipelines.',
    },
    {
      icon: '👥',
      title: 'Team Collaboration',
      description: 'Invite team members via GitHub org. Share strategies and track changes together.',
    },
    {
      icon: '🔐',
      title: 'Private Repos',
      description: 'Keep your proprietary strategies private. Only you and your team can access them.',
    },
    {
      icon: '📊',
      title: 'Version Control',
      description: 'Track every strategy change with Git. Rollback to any previous version instantly.',
    },
  ];

  return (
    <section id="github" className="py-20 relative">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-6">
            <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            <span className="text-sm font-medium text-white">GitHub Integration</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Connect Your <span className="gradient-text">GitHub Account</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Supercharge your trading with GitHub-powered strategy management, version control, and team collaboration.
          </p>
        </div>

        {/* Main Connect Card */}
        <div className="glass-card rounded-2xl p-8 mb-12 max-w-3xl mx-auto text-center border border-white/10">
          <div className="w-20 h-20 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
          </div>
          <h3 className="text-2xl font-bold mb-3">Sign in with GitHub</h3>
          <p className="text-gray-400 mb-6">
            Connect your GitHub account to access community strategies, deploy your own, and collaborate with your team.
          </p>
          <button className="px-8 py-4 bg-white text-dark rounded-xl font-semibold text-lg transition-all hover:shadow-xl hover:-translate-y-0.5 flex items-center gap-3 mx-auto">
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            Connect with GitHub
          </button>
          <p className="text-xs text-gray-500 mt-4">
            🔒 Secure OAuth 2.0 • We never access your private repos without permission
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="glass-card rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="text-3xl mb-3">{feature.icon}</div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Code example */}
        <div className="mt-12 glass-card rounded-2xl p-6 max-w-3xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-2 text-xs text-gray-400">strategy.py — Auto-deployed from GitHub</span>
          </div>
          <pre className="text-sm text-gray-300 overflow-x-auto">
            <code>{`# TradeBot Pro — GitHub Auto-Deploy Strategy
# Push to main branch to deploy to your bot

from tradebot import Bot, Strategy

class MySuperBotStrategy(Strategy):
    def on_tick(self, symbol, data):
        if symbol == "XAUUSD":
            if data.rsi < 30 and data.macd > 0:
                self.buy(symbol, lot=0.1)
        elif symbol == "BTCUSD":
            if data.bollinger_breakout == "upper":
                self.sell(symbol, lot=0.01)
                
# Deploy: git push origin main → Live in 30 seconds 🚀`}</code>
          </pre>
        </div>
      </div>
    </section>
  );
}
